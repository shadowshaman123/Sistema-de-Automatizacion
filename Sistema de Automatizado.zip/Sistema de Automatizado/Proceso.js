function validateInput(event) {

    var regex = /^[a-zA-Z]+$/;
    var input = event.target;
    var isValid = regex.test(input.value);
    
    if (!isValid) {
      input.value = input.value.slice(0, -1);
    }
  }

  var fnameInput = document.getElementById("fname");
  var lnameInput = document.getElementById("lname");
  
  fnameInput.addEventListener("input", validateInput);
  lnameInput.addEventListener("input", validateInput);

  function validateForm() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    if (fname.trim() === "") {
      alert("Por favor ingresa tu nombre ijueputa.");
      return false;
    }
    if (lname.trim() === "") {
      alert("Por favor ingresa tu apellido.");
      return false;
    }
    return true;
  }
  